let current = 186
let increment = 10
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  //first row
  stroke(10000)
 fill( `hsla( ${0 + current - increment + 50}, 50%, 50%, 1 )` );
  rect(1,0, 80,80)
 fill( `hsla( ${0 + current + increment }, 50%, 50%, 1 )` );
rect(81,0, 80,80)
  rect(160,0, 80,80)
   fill( `hsla( ${0 + current - increment + 50}, 50%, 50%, 1 )` );
  rect(240,0, 80,80)
 fill( `hsla( ${0 + current + increment }, 50%, 50%, 1 )` );
  rect(320,0, 80,80)
  //second row
 fill( `hsla( ${0 + current - increment + 60}, 50%, 50%, 1 )` );
    rect(1,80, 80,80)
  fill( `hsla( ${0 + current }, 50%, 50%, 1 )` );
  rect(81,80, 80,80)
 fill( `hsla( ${0 + current - increment + 60}, 50%, 50%, 1 )` );
  rect(160,80, 80,80)
   fill( `hsla( ${0 + current + increment }, 50%, 50%, 1 )` );
  rect(240,80, 80,80)
   fill( `hsla( ${0 + current }, 50%, 50%, 1 )` );
  rect(320,80, 80,80)
  //third row
  fill( `hsla( ${0 + current - increment + 70}, 50%, 50%, 1 )` );
   rect(1,160, 80,80)
  fill( `hsla( ${0 + current - increment + 70}, 50%, 50%, 1 )` );
  rect(81,160, 80,80)
  fill( `hsla( ${0 + current - increment *2 }, 50%, 50%, 1 )` );
  rect(160,160, 80,80)
  rect(240,160, 80,80)
  rect(320,160, 80,80)
  //fourth row
fill( `hsla( ${0 + current - increment + 80}, 50%, 50%, 1 )` );
  rect(1,240, 80,80)
  fill( `hsla( ${0 + current - increment *4}, 50%, 50%, 1 )` );
  rect(81,240, 80,80)
  fill( `hsla( ${0 + current - increment + 80}, 50%, 50%, 1 )` );
  rect(160,240, 80,80)
   fill( `hsla( ${0 + current - increment *2 }, 50%, 50%, 1 )` );
  rect(240,240, 80,80)
 fill( `hsla( ${0 + current - increment *4}, 50%, 50%, 1 )` );
  rect(320,240, 80,80)
  //fifth row
 fill( `hsla( ${0 + current - increment + 90}, 50%, 50%, 1 )` );
  rect(1,320, 80,80)
 fill( `hsla( ${0 + current - increment *4}, 50%, 50%, 1 )` );
  rect(81,320, 80,80)
  rect(160,320, 80,80)
   fill( `hsla( ${0 + current - increment + 90}, 50%, 50%, 1 )` );
  rect(240,320, 80,80)
     fill( `hsla( ${0 + current - increment *4}, 50%, 50%, 1 )` );
  rect(320,320, 80,80)
  
}